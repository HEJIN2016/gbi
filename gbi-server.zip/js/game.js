/**
 * Created by Administrator on 2017/12/28/028.
 * Option Game
 */

var $amount = $("#amount");
var $account = $("#account");
//判断登录状态

var option3 = indexOption3();
var GBIChart = echarts.init(document.getElementById('option'));
GBIChart.setOption(option3);
//        $(window).scroll(function () {
//            naverChange();
//        });
window.onresize = function () {
    GBIChart.resize();
    setHTMLFontSize();
}
//GBIGrapth(GBIChart,'transparent');
$(".history-btn .btn").click(function () {
    $(this).addClass('selected').siblings().removeClass('selected');
})

function getMinutesTime() {
    return {
        date: {
            date: [],
            timestamp: []
        }
    };
}

//Echarts绘图配置
var gameChart = {
    elemId: 'option',
    color: {
        type: 'linear',
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: [{
            offset: 0, color: 'rgba(119,186,230,0.11)'
        }, {
            offset: 1, color: 'rgba(138,205,172,0.11)'
        }]
    },
    //echarts loading参数
    defaultConfig: {
        text: 'loading',
        //color: '#c23531',
        textColor: '#fff',
         maskColor: '#0a0c10',
       // maskColor: 'rgba(46, 51, 53, 1)',
        zlevel: 0
    },
    option: indexOption2()
}

var playGameChart = echarts.init(document.getElementById(gameChart.elemId));

//二元期权游戏 试玩
var Game = {
    value: {
        date: {
            date: [],      //时间 format("HH:mm:ss")
            timestamp: []  //时间戳
        },
        data:[]            //指数数据
    },
    playUser: null,   //游戏玩家
    odds: 1,  //赔率
    playTimes: 0, //绘图次数
    startGameTime: null, //游戏开始时间
    xIndex: null,     //xIndex为赌局截止时间
    startIndex: null, //startIndex为赌局开始时的指数，
    stopGameTime: 0, // 结束时间

    //清除数据
    clearData: function(){
        this.value = {
            date: {
                date: [],      //时间 format("HH:mm:ss")
                timestamp: []  //时间戳
            },
            data:[]            //指数数据
        };
        this.playTimes = 0;
        this.startGameTime = null;
        this.xIndex = null;
        this.startIndex = null;
        this.stopGameTime = 0 ;
    },

    //echarts填充数据函数
    setChartOption: function(xIndex,startIndex,stopTime){
        playGameChart.setOption({
            xAxis: [{
                data: this.value.date.date
            }],
            series: [{
                data: this.value.data,
                areaStyle: {
                    normal: {
                        color: gameChart.color
                    }
                },
                markLine: {
                    data: [
                        {yAxis: startIndex, name: 'Start Index'},
                        {xAxis: getDateSecondTime(new Date(xIndex)), name: 'End Betting Time'},
                        {xAxis: getDateSecondTime(new Date(stopTime)), name: 'End Time'},
                    ]
                },
                markPoint: {
                    data: [{
                        xAxis: this.value.date.date[this.value.data.length - 1],
                        yAxis: this.value.data[this.value.data.length - 1]
                    }]
                }
            }]
        })
    },

    //初始化echarts
    initChart: function(){
        //gameChart.call(this,this.option,this.chart);
        playGameChart.setOption(gameChart.option);
    },
    //设置第一批时间和指数数据
    setInitData: function(){
        //清除数据
        this.value =  {
            date: {
                date: [],      //时间 format("HH:mm:ss")
                    timestamp: []  //时间戳
            },
            data:[]            //指数数据
        };
        //添加1分钟的时间数据，总共60s
        var startTime = Date.now();
        var i= 0;
        for(i = startTime; i < startTime + 60000; i+=1000){
            this.value.date.date.push(getDateSecondTime(new Date(i)));
            this.value.date.timestamp.push(i);
        }
        this.value.data.push(parseInt(11000 + 1600 * Math.random()));
        this.startIndex = this.value.data[0];
        var timeLength = this.value.date.timestamp.length;
        this.stopGameTime = this.value.date.timestamp[timeLength - 1];
    },
    //试玩功能，每过1s添加一条数据
    addGameData: function(state){
        var dataLength = this.value.data.length;
        this.value.data.push(parseInt(this.value.data[dataLength - 1] + this.value.data[dataLength - 1] * getRandomMultiple(state)));
        this.playTimes++;
    },
    //试玩游戏初始化
    initGame: function(){
        this.clearData();
        this.setInitData();
        var length = this.value.data.length;
        this.startGameTime = this.value.date.timestamp[0];
        //this.startIndex = this.value.data[9];
        this.startIndex = this.value.data[0];
        this.xIndex = this.startGameTime + 39000;
        this.setChartOption(this.xIndex,this.startIndex);
    },
    //试玩游戏定时器
    gameInter: null,
    //试玩函数入口
    init: function(obj){
        if(obj) {
            this.odds = obj.odds;
            this.playUser = obj.User;
        }
        if(this.gameInter) clearInterval(this.gameInter);
        this.initChart();
        this.initGame();
        this.gameInter = setInterval(function(){
            if(Date.now() < this.stopGameTime) {
                this.addGameData();
                var length = this.value.data.length;
                this.startGameTime = this.value.date.timestamp[0];
                //this.startIndex = this.value.data[length - 1];
                this.startIndex = this.value.data[0];
                this.xIndex = this.startGameTime + 39000;
                this.stopGameTime = this.value.date.timestamp[this.value.date.timestamp.length - 1];
                this.setChartOption(this.xIndex, this.startIndex, this.stopGameTime);
                //console.log(this.xIndex);
            } else {
                this.init();
            }
        }.bind(this),1000);
    },
    //开始试玩
    startPlayGames: function(state,amount){
        this.playUser.changeBalance((parseFloat($account.text()) - parseFloat(amount)).toFixed(2));//玩家余额减少
        $account.text(this.playUser.balance);
        $(".option-amount .btn").attr("disabled","disabled");
        clearInterval(this.gameInter);
        var currentDataLength = this.value.data.length;
        var startPlayIndex = this.value.data[currentDataLength - 1];
        var stopPlayIndex,gameResult;
        this.addGameData(state);
        this.setChartOption(this.xIndex,this.startIndex,this.stopGameTime);
        var playGames = setInterval(function(){
            if(Date.now() < this.stopGameTime) {
                this.addGameData();
                this.setChartOption(this.xIndex,this.startIndex,this.stopGameTime);
            }  else {
                this.addGameData();
                this.setChartOption(this.xIndex,this.startIndex);
                stopPlayIndex = this.value.data[this.value.data.length - 1];
                console.log(startPlayIndex);
                console.log(stopPlayIndex);
                //console.log(dataTimes.date.date[dataTimes.data.length - 1]);
                if(stopPlayIndex < startPlayIndex) gameResult = 0;
                else if(stopPlayIndex == startPlayIndex) gameResult = -1;
                else gameResult = 1;
                this.stop(state,amount,gameResult);
                clearInterval(playGames);
            }
        }.bind(this),1000);
    },
    //结束试玩游戏
    stop: function(state,amount,gameResult){
        console.log('stop game');
        $amount.removeAttr('disabled');
        $(".option-amount .btn").removeAttr('disabled');
        if(gameResult == state){
            $(".lose-result").css('display','none');
            $(".win-result").css('display','inline-block');
            $("#resultTitle").text('Good Prediction');
            this.playUser.changeBalance((parseFloat($account.text()) + parseFloat(amount)*(1 + this.odds)).toFixed(2));//玩家余额增加
            $account.text(this.playUser.balance);
            $(".win-result .balance").text((parseFloat(amount)*this.odds).toFixed(2));
        } else {
            $("#resultTitle").text('Bad Guess');
            $(".win-result").css('display','none');
            $(".lose-result").css('display','inline-block');
            $account.text((parseFloat($account.text())).toFixed(2));
            $(".lose-result .balance").text('-' + parseFloat(amount).toFixed(2));
        }
        judgeAmount();
        $("#result").show();

        //开始下一轮
        this.init();


        //this.gameInter = setInterval(function(){
        //    this.addGameData();
        //    var length = this.value.data.length;
        //    this.startGameTime = this.value.date.timestamp[length - 1];
        //    //this.startIndex = this.value.data[length - 1];
        //    this.startIndex = this.value.data[0];
        //    this.xIndex = this.startGameTime + 10000;
        //    this.setChartOption(this.xIndex,this.startIndex);
        //}.bind(this),1000);
    }
}

var coinMinUnit = 0.01;
//console.log(loginUser.getBalance());

//$account.text(loginUser.getBalance()?loginUser.getBalance():0);


var dataTimes = getMinutesTime();
var startValue,xValue,endTimes,value;
var newOption = false;
var times = 0;
var GBIIndex = [];
var timeUnit = 1;  //时间单位

function tradeData() {
    var trade = {}
}

//到截止交易时间时暂停交易
function pauseTradeOption(){
    $(".option-amount .btn").attr("disabled","disabled");
    $(".pause-trade-area").show();
}

//重新开始交易
function startTradeOption(){
    $(".option-amount .btn").removeAttr("disabled");
    $(".pause-trade-area").hide();
}


$(".close-result,.btn-area .btn").click(function(){
    $("#result").hide();
})

$amount.change(function(){
    judgeAmount();
})

$amount.get(0).oninput = function(){
    console.log('1');
    judgeAmount();
}

$(".reduce-area").click(function () {
    if(!$(this).attr('disabled')) {
        console.log('-');
        $amount.val($amount.val() > coinMinUnit ? (parseFloat($amount.val()) - coinMinUnit).toFixed(2) : coinMinUnit);
        judgeAmount();
    }
});
$(".add-area").click(function () {
    if(!$(this).attr('disabled')) {
        console.log('+');
        $amount.val((parseFloat($amount.val()) + coinMinUnit).toFixed(2));
        judgeAmount();
    }
});

//游戏结束时的结果显示
function stopOptionGame(result,winMoney){
    console.log(result);
    if(result == 1){
        $("#resultTitle").html('Good prediction');
        $(".lose-result").hide();
        $(".win-result").css('display','inline-block').find('span.balance').text(winMoney);
        $("#result").show();
    }//胜局
    else {
        $("#resultTitle").html('Bad Guess');
        $(".lose-result").css('display','inline-block').find('span.balance').text(winMoney);
        $(".win-result").hide();
        $("#result").show();
    }//平局以及败局
}

/*option二元期权Game*/
var optionGame = {

}



